"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OffscreenManager = void 0;
// Offscreen document manager for very long-running tasks (>5 minutes)
var OffscreenManager = /** @class */ (function () {
    function OffscreenManager() {
    }
    OffscreenManager.ensureOffscreenDocument = function () {
        return __awaiter(this, void 0, void 0, function () {
            var existingContexts, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        return [4 /*yield*/, chrome.runtime.getContexts({
                                contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
                            })];
                    case 1:
                        existingContexts = _a.sent();
                        if (existingContexts.length > 0) {
                            console.log('Offscreen document already exists');
                            return [2 /*return*/];
                        }
                        console.log('Creating offscreen document');
                        return [4 /*yield*/, chrome.offscreen.createDocument({
                                url: this.offscreenUrl,
                                reasons: [chrome.offscreen.Reason.WORKERS],
                                justification: 'Keep service worker alive during long-running AI tasks',
                            })];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _a.sent();
                        console.error('Failed to create offscreen document:', error_1);
                        throw error_1;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    OffscreenManager.closeOffscreenDocument = function () {
        return __awaiter(this, void 0, void 0, function () {
            var existingContexts, error_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        return [4 /*yield*/, chrome.runtime.getContexts({
                                contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
                            })];
                    case 1:
                        existingContexts = _a.sent();
                        if (existingContexts.length === 0) {
                            return [2 /*return*/];
                        }
                        console.log('Closing offscreen document');
                        return [4 /*yield*/, chrome.offscreen.closeDocument()];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        error_2 = _a.sent();
                        console.error('Failed to close offscreen document:', error_2);
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    OffscreenManager.sendToOffscreen = function (message) {
        return __awaiter(this, void 0, void 0, function () {
            var error_3;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, this.ensureOffscreenDocument()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, new Promise(function (resolve, reject) {
                                chrome.runtime.sendMessage(message, function (response) {
                                    if (chrome.runtime.lastError) {
                                        reject(new Error(chrome.runtime.lastError.message));
                                    }
                                    else {
                                        resolve(response);
                                    }
                                });
                            })];
                    case 2:
                        error_3 = _a.sent();
                        console.error('Failed to send message to offscreen:', error_3);
                        throw error_3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    OffscreenManager.offscreenUrl = 'offscreen.html';
    return OffscreenManager;
}());
exports.OffscreenManager = OffscreenManager;
